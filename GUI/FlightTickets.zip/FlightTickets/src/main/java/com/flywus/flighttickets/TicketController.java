package com.flywus.flighttickets;

import com.flywus.flighttickets.model.Flight;
import com.flywus.flighttickets.model.Passenger;
import com.flywus.flighttickets.model.Ticket;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.*;
import java.util.ArrayList;
import java.util.Optional;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;

public class TicketController {

    @FXML private TableView<Ticket> ticketTable;
    @FXML private TableColumn<Ticket, Void> rowNumberColumn;
    @FXML private TableColumn<Ticket, Integer> idColumn;
    @FXML private TableColumn<Ticket, String> seatNumberColumn;
    @FXML private TableColumn<Ticket, String> issueDateColumn;
    @FXML private TableColumn<Ticket, Double> totalCostColumn;
    @FXML private TableColumn<Ticket, Integer> flightIdColumn;
    @FXML private TableColumn<Ticket, Integer> passengerIdColumn;
    @FXML private TableColumn<Ticket, String> passportNumberColumn;

    @FXML private TextField seatNumberField;
    @FXML private TextField flightIdField;
    @FXML private TextField passportNumberField;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> searchCriteriaComboBox;
    @FXML private Label ticketCountLabel;

    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Button clearButton;
    @FXML private Button searchButton;

    private final String TICKET_FILE_PATH = "StorageFiles/tickets.txt";
    private final String FLIGHT_FILE_PATH = "StorageFiles/flights.txt";
    private final String PASSENGER_FILE_PATH = "StorageFiles/passengers.txt";

    private ObservableList<Ticket> ticketList = FXCollections.observableArrayList();
    private ObservableList<Ticket> allTickets = FXCollections.observableArrayList();
    private Ticket selectedTicket;

    @FXML
    private void initialize() {
        setupTableColumns();
        setupSearchCriteria();
        loadTickets();
        setupTableSelection();
        setupCounterBinding();
        updateButton.setDisable(true);
        deleteButton.setDisable(true);
    }

    private void setupSearchCriteria() {
        searchCriteriaComboBox.setItems(FXCollections.observableArrayList(
                "All Fields",
                "Seat Number",
                "Issue Date",
                "Total Cost",
                "Flight ID",
                "Passenger ID",
                "Passport Number"
        ));
        searchCriteriaComboBox.setValue("All Fields");
    }

    private void setupTableColumns() {
        // Setup row number column
        rowNumberColumn.setCellFactory(col -> {
            TableCell<Ticket, Void> cell = new TableCell<>();
            cell.textProperty().bind(Bindings.createStringBinding(() -> {
                if (cell.isEmpty()) {
                    return null;
                } else {
                    return Integer.toString(cell.getIndex() + 1);
                }
            }, cell.emptyProperty(), cell.indexProperty()));
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        seatNumberColumn.setCellValueFactory(new PropertyValueFactory<>("seatNumber"));
        issueDateColumn.setCellValueFactory(new PropertyValueFactory<>("issueDate"));
        totalCostColumn.setCellValueFactory(new PropertyValueFactory<>("totalCost"));
        flightIdColumn.setCellValueFactory(new PropertyValueFactory<>("flightId"));
        passengerIdColumn.setCellValueFactory(new PropertyValueFactory<>("passengerId"));

        passportNumberColumn.setCellValueFactory(cellData -> {
            Ticket ticket = cellData.getValue();
            Passenger passenger = getPassengerById(ticket.getPassengerId());
            return new javafx.beans.property.SimpleStringProperty(
                    passenger != null ? passenger.getPassportNumber() : "N/A"
            );
        });

        ticketTable.setItems(ticketList);
    }

    private void setupTableSelection() {
        ticketTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedTicket = newSelection;
                populateFields(newSelection);
                updateButton.setDisable(false);
                deleteButton.setDisable(false);
            } else {
                selectedTicket = null;
                updateButton.setDisable(true);
                deleteButton.setDisable(true);
            }
        });
    }

    private void setupCounterBinding() {
        ticketCountLabel.textProperty().bind(
                Bindings.createStringBinding(
                        () -> "Total Tickets: " + ticketList.size(),
                        ticketList
                )
        );
    }

    private void populateFields(Ticket ticket) {
        seatNumberField.setText(ticket.getSeatNumber());
        flightIdField.setText(String.valueOf(ticket.getFlightId()));
        // Find passenger passport number
        Passenger passenger = getPassengerById(ticket.getPassengerId());
        if (passenger != null) {
            passportNumberField.setText(passenger.getPassportNumber());
        }
    }

    @FXML
    private void handleAdd() {
        if (validateFields()) {
            try {
                int flightId = Integer.parseInt(flightIdField.getText());
                String passportNumber = passportNumberField.getText();

                // Validate flight exists
                Flight flight = getFlightById(flightId);
                if (flight == null) {
                    showAlert("Error", "Flight with ID " + flightId + " not found.", Alert.AlertType.ERROR);
                    return;
                }

                // Check available seats
                if (flight.getAvailableSeats() <= 0) {
                    showAlert("Error", "No available seats for this flight.", Alert.AlertType.ERROR);
                    return;
                }

                // Get passenger ID
                int passengerId = getPassengerIdByPassport(passportNumber);
                if (passengerId == -1) {
                    showAlert("Error", "Passenger with passport number " + passportNumber + " not found.", Alert.AlertType.ERROR);
                    return;
                }

                Ticket ticket = new Ticket(
                        seatNumberField.getText(),
                        flight.getPrice(),
                        flightId,
                        passengerId
                );

                ticketList.add(ticket);
                allTickets.add(ticket);
                decreaseAvailableSeats(flightId);
                saveTickets();
                clearFields();
                showAlert("Success", "Ticket created successfully! Ticket ID: " + ticket.getId(), Alert.AlertType.INFORMATION);

            } catch (NumberFormatException e) {
                showAlert("Error", "Please enter a valid flight ID.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleUpdate() {
        if (selectedTicket != null && validateFields()) {
            try {
                int newFlightId = Integer.parseInt(flightIdField.getText());
                String passportNumber = passportNumberField.getText();

                // Validate flight exists
                Flight flight = getFlightById(newFlightId);
                if (flight == null) {
                    showAlert("Error", "Flight with ID " + newFlightId + " not found.", Alert.AlertType.ERROR);
                    return;
                }

                // Get passenger ID
                int passengerId = getPassengerIdByPassport(passportNumber);
                if (passengerId == -1) {
                    showAlert("Error", "Passenger with passport number " + passportNumber + " not found.", Alert.AlertType.ERROR);
                    return;
                }

                // If flight changed, update seat availability
                if (selectedTicket.getFlightId() != newFlightId) {
                    increaseAvailableSeats(selectedTicket.getFlightId());
                    decreaseAvailableSeats(newFlightId);
                }

                selectedTicket.setSeatNumber(seatNumberField.getText());
                selectedTicket.setFlightId(newFlightId);
                selectedTicket.setPassengerId(passengerId);
                selectedTicket.setTotalCost(flight.getPrice());

                ticketTable.refresh();
                saveTickets();
                showAlert("Success", "Ticket updated successfully!", Alert.AlertType.INFORMATION);

            } catch (NumberFormatException e) {
                showAlert("Error", "Please enter a valid flight ID.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleDelete() {
        if (selectedTicket != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Delete");
            alert.setHeaderText("Delete Ticket");
            alert.setContentText("Are you sure you want to delete this ticket?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                increaseAvailableSeats(selectedTicket.getFlightId());
                ticketList.remove(selectedTicket);
                allTickets.remove(selectedTicket);
                saveTickets();
                clearFields();
                showAlert("Success", "Ticket deleted successfully!", Alert.AlertType.INFORMATION);
            }
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
        ticketTable.getSelectionModel().clearSelection();
        searchCriteriaComboBox.setValue("All Fields");
        searchField.clear();
        ticketList.setAll(allTickets);
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase().trim();
        String selectedCriteria = searchCriteriaComboBox.getValue();

        if (searchTerm.isEmpty()) {
            ticketList.setAll(allTickets);
            return;
        }

        ObservableList<Ticket> filteredList = FXCollections.observableArrayList();

        for (Ticket ticket : allTickets) {
            boolean matches = false;

            switch (selectedCriteria) {
                case "All Fields":
                    Passenger passenger = getPassengerById(ticket.getPassengerId());
                    String passportNumber = passenger != null ? passenger.getPassportNumber() : "";

                    matches = ticket.getSeatNumber().toLowerCase().contains(searchTerm) ||
                            ticket.getIssueDate().toLowerCase().contains(searchTerm) ||
                            String.valueOf(ticket.getTotalCost()).contains(searchTerm) ||
                            String.valueOf(ticket.getFlightId()).contains(searchTerm) ||
                            String.valueOf(ticket.getPassengerId()).contains(searchTerm) ||
                            passportNumber.toLowerCase().contains(searchTerm);
                    break;
                case "Seat Number":
                    matches = ticket.getSeatNumber().toLowerCase().contains(searchTerm);
                    break;
                case "Issue Date":
                    matches = ticket.getIssueDate().toLowerCase().contains(searchTerm);
                    break;
                case "Total Cost":
                    matches = String.valueOf(ticket.getTotalCost()).contains(searchTerm);
                    break;
                case "Flight ID":
                    matches = String.valueOf(ticket.getFlightId()).contains(searchTerm);
                    break;
                case "Passenger ID":
                    matches = String.valueOf(ticket.getPassengerId()).contains(searchTerm);
                    break;
                case "Passport Number":
                    Passenger passengerForPassport = getPassengerById(ticket.getPassengerId());
                    if (passengerForPassport != null) {
                        matches = passengerForPassport.getPassportNumber().toLowerCase().contains(searchTerm);
                    }
                    break;
            }

            if (matches) {
                filteredList.add(ticket);
            }
        }

        ticketList.setAll(filteredList);
    }

    private boolean validateFields() {
        if (seatNumberField.getText().isEmpty() || flightIdField.getText().isEmpty() ||
                passportNumberField.getText().isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return false;
        }

        try {
            Integer.parseInt(flightIdField.getText());
        } catch (NumberFormatException e) {
            showAlert("Error", "Flight ID must be a number.", Alert.AlertType.ERROR);
            return false;
        }

        return true;
    }

    private void clearFields() {
        seatNumberField.clear();
        flightIdField.clear();
        passportNumberField.clear();
    }

    private Flight getFlightById(int flightId) {
        ArrayList<Flight> flights = loadFlights();
        return flights.stream()
                .filter(f -> f.getId() == flightId)
                .findFirst()
                .orElse(null);
    }

    private Passenger getPassengerById(int passengerId) {
        ArrayList<Passenger> passengers = loadPassengers();
        return passengers.stream()
                .filter(p -> p.getId() == passengerId)
                .findFirst()
                .orElse(null);
    }

    private int getPassengerIdByPassport(String passportNumber) {
        ArrayList<Passenger> passengers = loadPassengers();
        return passengers.stream()
                .filter(p -> p.getPassportNumber().equals(passportNumber))
                .mapToInt(Passenger::getId)
                .findFirst()
                .orElse(-1);
    }

    private void decreaseAvailableSeats(int flightId) {
        ArrayList<Flight> flights = loadFlights();
        for (Flight flight : flights) {
            if (flight.getId() == flightId && flight.getAvailableSeats() > 0) {
                flight.setAvailableSeats(flight.getAvailableSeats() - 1);
                saveFlights(flights);
                break;
            }
        }
    }

    private void increaseAvailableSeats(int flightId) {
        ArrayList<Flight> flights = loadFlights();
        for (Flight flight : flights) {
            if (flight.getId() == flightId) {
                flight.setAvailableSeats(flight.getAvailableSeats() + 1);
                saveFlights(flights);
                break;
            }
        }
    }

    private ArrayList<Flight> loadFlights() {
        ArrayList<Flight> flights = new ArrayList<>();
        File file = new File(FLIGHT_FILE_PATH);

        if (!file.exists()) return flights;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 8) {
                    try {
                        flights.add(new Flight(
                                Integer.parseInt(parts[0]),
                                parts[1], parts[2], parts[3], parts[4], parts[5],
                                Double.parseDouble(parts[6]),
                                Integer.parseInt(parts[7])
                        ));
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping malformed flight line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return flights;
    }

    private ArrayList<Passenger> loadPassengers() {
        ArrayList<Passenger> passengers = new ArrayList<>();
        File file = new File(PASSENGER_FILE_PATH);

        if (!file.exists()) return passengers;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 6) {
                    try {
                        passengers.add(new Passenger(
                                Integer.parseInt(parts[0]),
                                parts[1], parts[2], parts[3], parts[4], parts[5]
                        ));
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping malformed passenger line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return passengers;
    }

    private void saveFlights(ArrayList<Flight> flights) {
        ensureStoragePath();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FLIGHT_FILE_PATH))) {
            for (Flight flight : flights) {
                bw.write(flight.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTickets() {
        ticketList.clear();
        allTickets.clear();
        File file = new File(TICKET_FILE_PATH);
        int maxId = 0;

        if (!file.exists()) {
            Ticket.setAutoIncId(1);
            return;
        }

        // Load passengers and flights first to validate ticket data
        ArrayList<Passenger> passengers = loadPassengers();
        ArrayList<Flight> flights = loadFlights();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 6) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String seatNumber = parts[1];
                        String issueDate = parts[2];
                        double totalCost = Double.parseDouble(parts[3]);
                        int flightId = Integer.parseInt(parts[4]);
                        int passengerId = Integer.parseInt(parts[5]);

                        // Check if both passenger and flight still exist
                        boolean passengerExists = passengers.stream()
                                .anyMatch(p -> p.getId() == passengerId);
                        boolean flightExists = flights.stream()
                                .anyMatch(f -> f.getId() == flightId);

                        if (passengerExists && flightExists) {
                            Ticket ticket = new Ticket(id, seatNumber, issueDate, totalCost, flightId, passengerId);
                            ticketList.add(ticket);
                            allTickets.add(ticket);

                            if (id > maxId) {
                                maxId = id;
                            }
                        } else {
                            if (!passengerExists) {
                                System.out.println("Skipping ticket " + id + " - passenger " + passengerId + " no longer exists");
                            }
                            if (!flightExists) {
                                System.out.println("Skipping ticket " + id + " - flight " + flightId + " no longer exists");
                            }
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping malformed ticket line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Error reading tickets file: " + e.getMessage(), Alert.AlertType.ERROR);
        }

        Ticket.setAutoIncId(maxId + 1);

        // Clean up the tickets file to remove orphaned tickets
        cleanupOrphanedTickets();
    }

    private void cleanupOrphanedTickets() {
        // Rewrite the tickets file with only valid tickets
        saveTickets();
    }

    // Add a public method to refresh the ticket data
    public void refreshTicketData() {
        loadTickets();
    }

    private void saveTickets() {
        ensureStoragePath();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(TICKET_FILE_PATH))) {
            for (Ticket ticket : allTickets) {
                bw.write(ticket.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            showAlert("Error", "Error saving tickets: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void ensureStoragePath() {
        File dir = new File("StorageFiles");
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleTabSelection() {
        // This method can be called when the ticket tab becomes active
        refreshTicketData();
    }
}
