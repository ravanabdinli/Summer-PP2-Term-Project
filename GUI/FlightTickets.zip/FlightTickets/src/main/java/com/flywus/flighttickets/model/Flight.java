package com.flywus.flighttickets.model;

import javafx.beans.property.*;

public class Flight {
    private static int _autoIncId = 1;
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty flightNumber = new SimpleStringProperty();
    private final StringProperty origin = new SimpleStringProperty();
    private final StringProperty destination = new SimpleStringProperty();
    private final StringProperty departureTime = new SimpleStringProperty();
    private final StringProperty arrivalTime = new SimpleStringProperty();
    private final DoubleProperty price = new SimpleDoubleProperty();
    private final IntegerProperty availableSeats = new SimpleIntegerProperty();

    public Flight(String flightNumber, String origin, String destination, String departureTime,
                  String arrivalTime, double price, int availableSeats) {
        this.id.set(_autoIncId++);
        this.flightNumber.set(flightNumber);
        this.origin.set(origin);
        this.destination.set(destination);
        this.departureTime.set(departureTime);
        this.arrivalTime.set(arrivalTime);
        this.price.set(price);
        this.availableSeats.set(availableSeats);
    }

    public Flight(int id, String flightNumber, String origin, String destination, String departureTime,
                  String arrivalTime, double price, int availableSeats) {
        this.id.set(id);
        this.flightNumber.set(flightNumber);
        this.origin.set(origin);
        this.destination.set(destination);
        this.departureTime.set(departureTime);
        this.arrivalTime.set(arrivalTime);
        this.price.set(price);
        this.availableSeats.set(availableSeats);
    }

    public static void setAutoIncId(int newId) {
        _autoIncId = newId;
    }

    // Property getters
    public IntegerProperty idProperty() { return id; }
    public StringProperty flightNumberProperty() { return flightNumber; }
    public StringProperty originProperty() { return origin; }
    public StringProperty destinationProperty() { return destination; }
    public StringProperty departureTimeProperty() { return departureTime; }
    public StringProperty arrivalTimeProperty() { return arrivalTime; }
    public DoubleProperty priceProperty() { return price; }
    public IntegerProperty availableSeatsProperty() { return availableSeats; }

    // Getters
    public int getId() { return id.get(); }
    public String getFlightNumber() { return flightNumber.get(); }
    public String getOrigin() { return origin.get(); }
    public String getDestination() { return destination.get(); }
    public String getDepartureTime() { return departureTime.get(); }
    public String getArrivalTime() { return arrivalTime.get(); }
    public double getPrice() { return price.get(); }
    public int getAvailableSeats() { return availableSeats.get(); }

    // Setters
    public void setId(int id) { this.id.set(id); }
    public void setFlightNumber(String flightNumber) { this.flightNumber.set(flightNumber); }
    public void setOrigin(String origin) { this.origin.set(origin); }
    public void setDestination(String destination) { this.destination.set(destination); }
    public void setDepartureTime(String departureTime) { this.departureTime.set(departureTime); }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime.set(arrivalTime); }
    public void setPrice(double price) { this.price.set(price); }
    public void setAvailableSeats(int availableSeats) { this.availableSeats.set(availableSeats); }

    @Override
    public String toString() {
        return getId() + ";" + getFlightNumber() + ";" + getOrigin() + ";" + getDestination() + ";" +
                getDepartureTime() + ";" + getArrivalTime() + ";" + getPrice() + ";" + getAvailableSeats();
    }
}