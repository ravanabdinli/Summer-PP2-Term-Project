package com.flywus.flighttickets.model;

import javafx.beans.property.*;

public class Passenger {
    private static int _autoIncId = 1;
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty name = new SimpleStringProperty();
    private final StringProperty address = new SimpleStringProperty();
    private final StringProperty phoneNumber = new SimpleStringProperty();
    private final StringProperty email = new SimpleStringProperty();
    private final StringProperty passportNumber = new SimpleStringProperty();

    public Passenger(String name, String address, String phoneNumber, String email, String passportNumber) {
        this.id.set(_autoIncId++);
        this.name.set(name);
        this.address.set(address);
        this.phoneNumber.set(phoneNumber);
        this.email.set(email);
        this.passportNumber.set(passportNumber);
    }

    public Passenger(int id, String name, String address, String phoneNumber, String email, String passportNumber) {
        this.id.set(id);
        this.name.set(name);
        this.address.set(address);
        this.phoneNumber.set(phoneNumber);
        this.email.set(email);
        this.passportNumber.set(passportNumber);
    }

    public static void setAutoIncId(int value) {
        _autoIncId = value;
    }

    // Property getters
    public IntegerProperty idProperty() { return id; }
    public StringProperty nameProperty() { return name; }
    public StringProperty addressProperty() { return address; }
    public StringProperty phoneNumberProperty() { return phoneNumber; }
    public StringProperty emailProperty() { return email; }
    public StringProperty passportNumberProperty() { return passportNumber; }

    // Getters
    public int getId() { return id.get(); }
    public String getName() { return name.get(); }
    public String getAddress() { return address.get(); }
    public String getPhoneNumber() { return phoneNumber.get(); }
    public String getEmail() { return email.get(); }
    public String getPassportNumber() { return passportNumber.get(); }

    // Setters
    public void setId(int id) { this.id.set(id); }
    public void setName(String name) { this.name.set(name); }
    public void setAddress(String address) { this.address.set(address); }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber.set(phoneNumber); }
    public void setEmail(String email) { this.email.set(email); }
    public void setPassportNumber(String passportNumber) { this.passportNumber.set(passportNumber); }

    @Override
    public String toString() {
        return getId() + ";" + getName() + ";" + getAddress() + ";" + getPhoneNumber() + ";" + getEmail() + ";" + getPassportNumber();
    }
}