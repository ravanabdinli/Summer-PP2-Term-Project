package com.flywus.flighttickets;

import com.flywus.flighttickets.model.Flight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.*;
import java.util.Optional;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import java.util.ArrayList;
import javafx.scene.control.ComboBox;

public class FlightController {

    @FXML private TableView<Flight> flightTable;
    @FXML private TableColumn<Flight, Void> rowNumberColumn;
    @FXML private TableColumn<Flight, Integer> idColumn;
    @FXML private TableColumn<Flight, String> flightNumberColumn;
    @FXML private TableColumn<Flight, String> originColumn;
    @FXML private TableColumn<Flight, String> destinationColumn;
    @FXML private TableColumn<Flight, String> departureTimeColumn;
    @FXML private TableColumn<Flight, String> arrivalTimeColumn;
    @FXML private TableColumn<Flight, Double> priceColumn;
    @FXML private TableColumn<Flight, Integer> availableSeatsColumn;

    @FXML private TextField flightNumberField;
    @FXML private TextField originField;
    @FXML private TextField destinationField;
    @FXML private TextField departureTimeField;
    @FXML private TextField arrivalTimeField;
    @FXML private TextField priceField;
    @FXML private TextField availableSeatsField;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> searchFieldComboBox;

    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Button clearButton;
    @FXML private Button searchButton;

    @FXML private Label flightCountLabel;

    private final String FILE_PATH = "StorageFiles/flights.txt";
    private ObservableList<Flight> flightList = FXCollections.observableArrayList();
    private ObservableList<Flight> allFlights = FXCollections.observableArrayList(); // Keep original data
    private Flight selectedFlight;

    @FXML
    private void initialize() {
        setupTableColumns();
        setupSearchComboBox();
        loadFlights();
        setupTableSelection();
        setupCounterBinding();
        updateButton.setDisable(true);
        deleteButton.setDisable(true);
    }

    private void setupTableColumns() {
        // Setup row number column
        rowNumberColumn.setCellFactory(col -> {
            TableCell<Flight, Void> cell = new TableCell<>();
            cell.textProperty().bind(Bindings.createStringBinding(() -> {
                if (cell.isEmpty()) {
                    return null;
                } else {
                    return Integer.toString(cell.getIndex() + 1);
                }
            }, cell.emptyProperty(), cell.indexProperty()));
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        flightNumberColumn.setCellValueFactory(new PropertyValueFactory<>("flightNumber"));
        originColumn.setCellValueFactory(new PropertyValueFactory<>("origin"));
        destinationColumn.setCellValueFactory(new PropertyValueFactory<>("destination"));
        departureTimeColumn.setCellValueFactory(new PropertyValueFactory<>("departureTime"));
        arrivalTimeColumn.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        availableSeatsColumn.setCellValueFactory(new PropertyValueFactory<>("availableSeats"));

        flightTable.setItems(flightList);
    }

    private void setupSearchComboBox() {
        searchFieldComboBox.getItems().addAll(
                "All Fields",
                "Flight Number",
                "Origin",
                "Destination",
                "Departure Time",
                "Arrival Time",
                "Price",
                "Available Seats"
        );
        searchFieldComboBox.setValue("All Fields"); // Set default selection
    }

    private void setupTableSelection() {
        flightTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedFlight = newSelection;
                populateFields(newSelection);
                updateButton.setDisable(false);
                deleteButton.setDisable(false);
            } else {
                selectedFlight = null;
                updateButton.setDisable(true);
                deleteButton.setDisable(true);
            }
        });
    }

    private void setupCounterBinding() {
        flightCountLabel.textProperty().bind(
                Bindings.createStringBinding(
                        () -> "Total Flights: " + flightList.size(),
                        flightList
                )
        );
    }

    private void populateFields(Flight flight) {
        flightNumberField.setText(flight.getFlightNumber());
        originField.setText(flight.getOrigin());
        destinationField.setText(flight.getDestination());
        departureTimeField.setText(flight.getDepartureTime());
        arrivalTimeField.setText(flight.getArrivalTime());
        priceField.setText(String.valueOf(flight.getPrice()));
        availableSeatsField.setText(String.valueOf(flight.getAvailableSeats()));
    }

    @FXML
    private void handleAdd() {
        if (validateFields()) {
            try {
                Flight flight = new Flight(
                        flightNumberField.getText(),
                        originField.getText(),
                        destinationField.getText(),
                        departureTimeField.getText(),
                        arrivalTimeField.getText(),
                        Double.parseDouble(priceField.getText()),
                        Integer.parseInt(availableSeatsField.getText())
                );

                allFlights.add(flight);
                saveFlights();
                refreshTable();
                clearFields();
                showAlert("Success", "Flight added successfully!", Alert.AlertType.INFORMATION);
            } catch (NumberFormatException e) {
                showAlert("Error", "Please enter valid numbers for price and seats.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleUpdate() {
        if (selectedFlight != null && validateFields()) {
            try {
                selectedFlight.setFlightNumber(flightNumberField.getText());
                selectedFlight.setOrigin(originField.getText());
                selectedFlight.setDestination(destinationField.getText());
                selectedFlight.setDepartureTime(departureTimeField.getText());
                selectedFlight.setArrivalTime(arrivalTimeField.getText());
                selectedFlight.setPrice(Double.parseDouble(priceField.getText()));
                selectedFlight.setAvailableSeats(Integer.parseInt(availableSeatsField.getText()));

                flightTable.refresh();
                saveFlights();
                refreshTable();
                showAlert("Success", "Flight updated successfully!", Alert.AlertType.INFORMATION);
            } catch (NumberFormatException e) {
                showAlert("Error", "Please enter valid numbers for price and seats.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleDelete() {
        if (selectedFlight != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Delete");
            alert.setHeaderText("Delete Flight");
            alert.setContentText("Are you sure you want to delete this flight?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                deleteFlightTickets(selectedFlight.getId());
                allFlights.remove(selectedFlight);
                saveFlights();
                refreshTable();
                clearFields();
                showAlert("Success", "Flight and associated tickets deleted successfully!", Alert.AlertType.INFORMATION);
            }
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
        flightTable.getSelectionModel().clearSelection();
        searchField.clear();
        searchFieldComboBox.setValue("All Fields"); // Reset to default
        refreshTable(); // Show all data when clearing
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase().trim();
        String selectedField = searchFieldComboBox.getValue();

        if (searchTerm.isEmpty()) {
            refreshTable(); // Show all data if search is empty
            return;
        }

        ObservableList<Flight> filteredList = FXCollections.observableArrayList();

        for (Flight flight : allFlights) {
            boolean matches = false;

            switch (selectedField) {
                case "All Fields":
                    matches = flight.getFlightNumber().toLowerCase().contains(searchTerm) ||
                            flight.getOrigin().toLowerCase().contains(searchTerm) ||
                            flight.getDestination().toLowerCase().contains(searchTerm) ||
                            flight.getDepartureTime().toLowerCase().contains(searchTerm) ||
                            flight.getArrivalTime().toLowerCase().contains(searchTerm) ||
                            String.valueOf(flight.getPrice()).contains(searchTerm) ||
                            String.valueOf(flight.getAvailableSeats()).contains(searchTerm);
                    break;
                case "Flight Number":
                    matches = flight.getFlightNumber().toLowerCase().contains(searchTerm);
                    break;
                case "Origin":
                    matches = flight.getOrigin().toLowerCase().contains(searchTerm);
                    break;
                case "Destination":
                    matches = flight.getDestination().toLowerCase().contains(searchTerm);
                    break;
                case "Departure Time":
                    matches = flight.getDepartureTime().toLowerCase().contains(searchTerm);
                    break;
                case "Arrival Time":
                    matches = flight.getArrivalTime().toLowerCase().contains(searchTerm);
                    break;
                case "Price":
                    matches = String.valueOf(flight.getPrice()).contains(searchTerm);
                    break;
                case "Available Seats":
                    matches = String.valueOf(flight.getAvailableSeats()).contains(searchTerm);
                    break;
            }

            if (matches) {
                filteredList.add(flight);
            }
        }

        flightList.setAll(filteredList);
    }

    private void refreshTable() {
        flightList.setAll(allFlights);
    }

    private boolean validateFields() {
        if (flightNumberField.getText().isEmpty() || originField.getText().isEmpty() ||
                destinationField.getText().isEmpty() || departureTimeField.getText().isEmpty() ||
                arrivalTimeField.getText().isEmpty() || priceField.getText().isEmpty() ||
                availableSeatsField.getText().isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return false;
        }

        if (!departureTimeField.getText().matches("\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}")) {
            showAlert("Error", "Departure time must be in format DD/MM/YYYY HH:MM", Alert.AlertType.ERROR);
            return false;
        }

        if (!arrivalTimeField.getText().matches("\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}")) {
            showAlert("Error", "Arrival time must be in format DD/MM/YYYY HH:MM", Alert.AlertType.ERROR);
            return false;
        }

        try {
            double price = Double.parseDouble(priceField.getText());
            int seats = Integer.parseInt(availableSeatsField.getText());
            if (price < 0 || seats < 0) {
                showAlert("Error", "Price and seats cannot be negative.", Alert.AlertType.ERROR);
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter valid numbers for price and seats.", Alert.AlertType.ERROR);
            return false;
        }

        return true;
    }

    private void clearFields() {
        flightNumberField.clear();
        originField.clear();
        destinationField.clear();
        departureTimeField.clear();
        arrivalTimeField.clear();
        priceField.clear();
        availableSeatsField.clear();
    }

    private void loadFlights() {
        allFlights.clear();
        File file = new File(FILE_PATH);
        int maxId = 0;

        if (!file.exists()) {
            Flight.setAutoIncId(1);
            refreshTable();
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 8) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String flightNumber = parts[1];
                        String origin = parts[2];
                        String destination = parts[3];
                        String departureTime = parts[4];
                        String arrivalTime = parts[5];
                        double price = Double.parseDouble(parts[6]);
                        int availableSeats = Integer.parseInt(parts[7]);

                        Flight flight = new Flight(id, flightNumber, origin, destination, departureTime, arrivalTime, price, availableSeats);
                        allFlights.add(flight);

                        if (id > maxId) {
                            maxId = id;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping malformed line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Error reading flights file: " + e.getMessage(), Alert.AlertType.ERROR);
        }

        Flight.setAutoIncId(maxId + 1);
        refreshTable();
    }

    private void saveFlights() {
        ensureStoragePath();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Flight flight : allFlights) {
                bw.write(flight.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            showAlert("Error", "Error saving flights: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void ensureStoragePath() {
        File dir = new File("StorageFiles");
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    private void deleteFlightTickets(int flightId) {
        File ticketFile = new File("StorageFiles/tickets.txt");
        if (!ticketFile.exists()) return;

        ArrayList<String> remainingTickets = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ticketFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 6) {
                    try {
                        int ticketFlightId = Integer.parseInt(parts[4]);
                        if (ticketFlightId != flightId) {
                            remainingTickets.add(line);
                        }
                    } catch (NumberFormatException e) {
                        remainingTickets.add(line); // Keep malformed lines
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading tickets file: " + e.getMessage());
            return;
        }

        // Write back the remaining tickets
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ticketFile))) {
            for (String ticket : remainingTickets) {
                bw.write(ticket);
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error updating tickets file: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
