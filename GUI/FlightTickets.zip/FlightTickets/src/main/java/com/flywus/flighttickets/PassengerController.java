package com.flywus.flighttickets;

import com.flywus.flighttickets.model.Passenger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.*;
import java.util.Optional;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;

public class PassengerController {

    @FXML private TableView<Passenger> passengerTable;
    @FXML private TableColumn<Passenger, Integer> idColumn;
    @FXML private TableColumn<Passenger, String> nameColumn;
    @FXML private TableColumn<Passenger, String> addressColumn;
    @FXML private TableColumn<Passenger, String> phoneColumn;
    @FXML private TableColumn<Passenger, String> emailColumn;
    @FXML private TableColumn<Passenger, String> passportColumn;
    @FXML private TableColumn<Passenger, Void> rowNumberColumn;

    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private TextField phoneField;
    @FXML private TextField emailField;
    @FXML private TextField passportField;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> searchFieldComboBox;
    @FXML private Label passengerCountLabel;

    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Button clearButton;
    @FXML private Button searchButton;

    private final String FILE_PATH = "StorageFiles/passengers.txt";
    private ObservableList<Passenger> passengerList = FXCollections.observableArrayList();
    private ObservableList<Passenger> allPassengers = FXCollections.observableArrayList(); // Keep original data
    private Passenger selectedPassenger;

    @FXML
    private void initialize() {
        setupTableColumns();
        setupSearchComboBox();
        loadPassengers();
        setupTableSelection();
        setupCounterBinding();
        updateButton.setDisable(true);
        deleteButton.setDisable(true);
    }

    private void setupTableColumns() {
        // Setup row number column
        rowNumberColumn.setCellFactory(col -> {
            TableCell<Passenger, Void> cell = new TableCell<>();
            cell.textProperty().bind(Bindings.createStringBinding(() -> {
                if (cell.isEmpty()) {
                    return null;
                } else {
                    return Integer.toString(cell.getIndex() + 1);
                }
            }, cell.emptyProperty(), cell.indexProperty()));
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        passportColumn.setCellValueFactory(new PropertyValueFactory<>("passportNumber"));

        passengerTable.setItems(passengerList);
    }

    private void setupSearchComboBox() {
        searchFieldComboBox.getItems().addAll(
                "All Fields",
                "Name",
                "Address",
                "Phone Number",
                "Email",
                "Passport Number"
        );
        searchFieldComboBox.setValue("All Fields"); // Set default selection
    }

    private void setupTableSelection() {
        passengerTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedPassenger = newSelection;
                populateFields(newSelection);
                updateButton.setDisable(false);
                deleteButton.setDisable(false);
            } else {
                selectedPassenger = null;
                updateButton.setDisable(true);
                deleteButton.setDisable(true);
            }
        });
    }

    private void setupCounterBinding() {
        passengerCountLabel.textProperty().bind(
                Bindings.createStringBinding(
                        () -> "Total Passengers: " + passengerList.size(),
                        passengerList
                )
        );
    }

    private void populateFields(Passenger passenger) {
        nameField.setText(passenger.getName());
        addressField.setText(passenger.getAddress());
        phoneField.setText(passenger.getPhoneNumber());
        emailField.setText(passenger.getEmail());
        passportField.setText(passenger.getPassportNumber());
    }

    @FXML
    private void handleAdd() {
        if (validateFields()) {
            String passportNumber = passportField.getText();

            // Check if passport number is unique
            if (!isPassportNumberUnique(passportNumber, null)) {
                showAlert("Error", "Passport number already exists. Passport numbers must be unique.", Alert.AlertType.ERROR);
                return;
            }

            Passenger passenger = new Passenger(
                    nameField.getText(),
                    addressField.getText(),
                    phoneField.getText(),
                    emailField.getText(),
                    passportNumber
            );

            allPassengers.add(passenger);
            savePassengers();
            refreshTable();
            clearFields();
            showAlert("Success", "Passenger added successfully!", Alert.AlertType.INFORMATION);
        }
    }

    @FXML
    private void handleUpdate() {
        if (selectedPassenger != null && validateFields()) {
            String passportNumber = passportField.getText();

            // Check if passport number is unique (excluding the current passenger)
            if (!isPassportNumberUnique(passportNumber, selectedPassenger.getId())) {
                showAlert("Error", "Passport number already exists. Passport numbers must be unique.", Alert.AlertType.ERROR);
                return;
            }

            selectedPassenger.setName(nameField.getText());
            selectedPassenger.setAddress(addressField.getText());
            selectedPassenger.setPhoneNumber(phoneField.getText());
            selectedPassenger.setEmail(emailField.getText());
            selectedPassenger.setPassportNumber(passportNumber);

            passengerTable.refresh();
            savePassengers();
            refreshTable();
            showAlert("Success", "Passenger updated successfully!", Alert.AlertType.INFORMATION);
        }
    }

    @FXML
    private void handleDelete() {
        if (selectedPassenger != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Delete");
            alert.setHeaderText("Delete Passenger");
            alert.setContentText("Are you sure you want to delete this passenger? This will also delete all associated tickets.");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Delete all tickets associated with this passenger
                deletePassengerTickets(selectedPassenger.getId());

                allPassengers.remove(selectedPassenger);
                savePassengers();
                refreshTable();
                clearFields();
                showAlert("Success", "Passenger and associated tickets deleted successfully!", Alert.AlertType.INFORMATION);
            }
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
        passengerTable.getSelectionModel().clearSelection();
        searchField.clear();
        searchFieldComboBox.setValue("All Fields"); // Reset to default
        refreshTable(); // Show all data when clearing
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase().trim();
        String selectedField = searchFieldComboBox.getValue();

        if (searchTerm.isEmpty()) {
            refreshTable(); // Show all data if search is empty
            return;
        }

        ObservableList<Passenger> filteredList = FXCollections.observableArrayList();

        for (Passenger passenger : allPassengers) {
            boolean matches = false;

            switch (selectedField) {
                case "All Fields":
                    matches = passenger.getName().toLowerCase().contains(searchTerm) ||
                            passenger.getAddress().toLowerCase().contains(searchTerm) ||
                            passenger.getPhoneNumber().toLowerCase().contains(searchTerm) ||
                            passenger.getEmail().toLowerCase().contains(searchTerm) ||
                            passenger.getPassportNumber().toLowerCase().contains(searchTerm);
                    break;
                case "Name":
                    matches = passenger.getName().toLowerCase().contains(searchTerm);
                    break;
                case "Address":
                    matches = passenger.getAddress().toLowerCase().contains(searchTerm);
                    break;
                case "Phone Number":
                    matches = passenger.getPhoneNumber().toLowerCase().contains(searchTerm);
                    break;
                case "Email":
                    matches = passenger.getEmail().toLowerCase().contains(searchTerm);
                    break;
                case "Passport Number":
                    matches = passenger.getPassportNumber().toLowerCase().contains(searchTerm);
                    break;
            }

            if (matches) {
                filteredList.add(passenger);
            }
        }

        passengerList.setAll(filteredList);
    }

    private void refreshTable() {
        passengerList.setAll(allPassengers);
    }

    private void deletePassengerTickets(int passengerId) {
        try {
            File ticketFile = new File("StorageFiles/tickets.txt");
            if (!ticketFile.exists()) return;

            java.util.List<String> remainingTickets = new java.util.ArrayList<>();

            try (BufferedReader br = new BufferedReader(new FileReader(ticketFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(";");
                    if (parts.length == 6) {
                        int ticketPassengerId = Integer.parseInt(parts[5]);
                        if (ticketPassengerId != passengerId) {
                            remainingTickets.add(line);
                        } else {
                            // Restore seat availability for deleted tickets
                            int flightId = Integer.parseInt(parts[4]);
                            restoreFlightSeat(flightId);
                        }
                    }
                }
            }

            // Write back the remaining tickets
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(ticketFile))) {
                for (String ticket : remainingTickets) {
                    bw.write(ticket);
                    bw.newLine();
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error deleting passenger tickets: " + e.getMessage());
        }
    }

    private void restoreFlightSeat(int flightId) {
        try {
            File flightFile = new File("StorageFiles/flights.txt");
            if (!flightFile.exists()) return;

            java.util.List<String> flights = new java.util.ArrayList<>();

            try (BufferedReader br = new BufferedReader(new FileReader(flightFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(";");
                    if (parts.length == 8 && Integer.parseInt(parts[0]) == flightId) {
                        int availableSeats = Integer.parseInt(parts[7]) + 1;
                        parts[7] = String.valueOf(availableSeats);
                        flights.add(String.join(";", parts));
                    } else {
                        flights.add(line);
                    }
                }
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(flightFile))) {
                for (String flight : flights) {
                    bw.write(flight);
                    bw.newLine();
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error restoring flight seat: " + e.getMessage());
        }
    }

    private boolean validateFields() {
        if (nameField.getText().isEmpty() || addressField.getText().isEmpty() ||
                phoneField.getText().isEmpty() || emailField.getText().isEmpty() ||
                passportField.getText().isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return false;
        }

        if (!phoneField.getText().matches("\\+?\\d{7,15}")) {
            showAlert("Error", "Invalid phone number format.", Alert.AlertType.ERROR);
            return false;
        }

        if (!emailField.getText().matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
            showAlert("Error", "Invalid email format.", Alert.AlertType.ERROR);
            return false;
        }

        return true;
    }

    private boolean isPassportNumberUnique(String passportNumber, Integer excludeId) {
        for (Passenger passenger : allPassengers) {
            // Skip the current passenger when updating (by ID)
            if (excludeId != null && passenger.getId() == excludeId) {
                continue;
            }

            if (passenger.getPassportNumber().equals(passportNumber)) {
                return false; // Found a duplicate
            }
        }
        return true; // No duplicates found
    }

    private void clearFields() {
        nameField.clear();
        addressField.clear();
        phoneField.clear();
        emailField.clear();
        passportField.clear();
    }

    private void loadPassengers() {
        allPassengers.clear();
        File file = new File(FILE_PATH);
        int maxId = 0;

        if (!file.exists()) {
            Passenger.setAutoIncId(1);
            refreshTable();
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 6) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String name = parts[1];
                        String address = parts[2];
                        String phone = parts[3];
                        String email = parts[4];
                        String passport = parts[5];

                        Passenger passenger = new Passenger(id, name, address, phone, email, passport);
                        allPassengers.add(passenger);

                        if (id > maxId) {
                            maxId = id;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping malformed line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Error reading passengers file: " + e.getMessage(), Alert.AlertType.ERROR);
        }

        Passenger.setAutoIncId(maxId + 1);
        refreshTable();
    }

    private void savePassengers() {
        ensureStoragePath();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Passenger passenger : allPassengers) {
                bw.write(passenger.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            showAlert("Error", "Error saving passengers: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void ensureStoragePath() {
        File dir = new File("StorageFiles");
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
