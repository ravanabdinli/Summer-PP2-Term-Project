package com.flywus.flighttickets;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

public class MainController {

    @FXML
    private TabPane mainTabPane;

    @FXML
    private Tab flightTab;

    @FXML
    private Tab passengerTab;

    @FXML
    private Tab ticketTab;

    private TicketController ticketController;

    @FXML
    private void initialize() {
        loadFlightView();
        loadPassengerView();
        loadTicketView();
        setupTabSelectionListener();
    }

    private void setupTabSelectionListener() {
        mainTabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == ticketTab && ticketController != null) {
                // Refresh ticket data when ticket tab is selected
                ticketController.refreshTicketData();
            }
        });
    }

    private void loadFlightView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/flywus/flighttickets/FlightView.fxml"));
            AnchorPane flightView = loader.load();
            flightTab.setContent(flightView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadPassengerView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/flywus/flighttickets/PassengerView.fxml"));
            AnchorPane passengerView = loader.load();
            passengerTab.setContent(passengerView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadTicketView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/flywus/flighttickets/TicketView.fxml"));
            AnchorPane ticketView = loader.load();
            ticketController = loader.getController(); // Store reference to controller
            ticketTab.setContent(ticketView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
