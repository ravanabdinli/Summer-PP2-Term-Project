package com.flywus.flighttickets.model;

import javafx.beans.property.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Ticket {
    private static int _autoIncId = 1;
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty seatNumber = new SimpleStringProperty();
    private final StringProperty issueDate = new SimpleStringProperty();
    private final DoubleProperty totalCost = new SimpleDoubleProperty();
    private final IntegerProperty flightId = new SimpleIntegerProperty();
    private final IntegerProperty passengerId = new SimpleIntegerProperty();

    public Ticket(int id, String seatNumber, String issueDate, double totalCost, int flightId, int passengerId) {
        this.id.set(id);
        this.seatNumber.set(seatNumber);
        this.issueDate.set(issueDate);
        this.totalCost.set(totalCost);
        this.flightId.set(flightId);
        this.passengerId.set(passengerId);
    }

    public Ticket(String seatNumber, double totalCost, int flightId, int passengerId) {
        this.id.set(_autoIncId++);
        this.seatNumber.set(seatNumber);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        this.issueDate.set(LocalDateTime.now().format(formatter));
        this.totalCost.set(totalCost);
        this.flightId.set(flightId);
        this.passengerId.set(passengerId);
    }

    public static void setAutoIncId(int id) {
        _autoIncId = id;
    }

    public static int getAutoIncId() {
        return _autoIncId;
    }

    // Property getters
    public IntegerProperty idProperty() { return id; }
    public StringProperty seatNumberProperty() { return seatNumber; }
    public StringProperty issueDateProperty() { return issueDate; }
    public DoubleProperty totalCostProperty() { return totalCost; }
    public IntegerProperty flightIdProperty() { return flightId; }
    public IntegerProperty passengerIdProperty() { return passengerId; }

    // Getters
    public int getId() { return id.get(); }
    public String getSeatNumber() { return seatNumber.get(); }
    public String getIssueDate() { return issueDate.get(); }
    public double getTotalCost() { return totalCost.get(); }
    public int getFlightId() { return flightId.get(); }
    public int getPassengerId() { return passengerId.get(); }

    // Setters
    public void setId(int id) { this.id.set(id); }
    public void setSeatNumber(String seatNumber) { this.seatNumber.set(seatNumber); }
    public void setIssueDate(String issueDate) { this.issueDate.set(issueDate); }
    public void setTotalCost(double totalCost) { this.totalCost.set(totalCost); }
    public void setFlightId(int flightId) { this.flightId.set(flightId); }
    public void setPassengerId(int passengerId) { this.passengerId.set(passengerId); }

    @Override
    public String toString() {
        return getId() + ";" + getSeatNumber() + ";" + getIssueDate() + ";" + getTotalCost() + ";" + getFlightId() + ";" + getPassengerId();
    }
}