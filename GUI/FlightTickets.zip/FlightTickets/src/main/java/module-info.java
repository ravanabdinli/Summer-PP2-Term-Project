module com.flywus.flighttickets {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    opens com.flywus.flighttickets to javafx.fxml;
    opens com.flywus.flighttickets.model to javafx.fxml;

    exports com.flywus.flighttickets;
    exports com.flywus.flighttickets.model;
}